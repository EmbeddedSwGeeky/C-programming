#include <stdio.h>

inline int sum(int x, int y)
{
    return x + y;
}

int main()
{
    int res;

    res = sum(5, 10);
}
