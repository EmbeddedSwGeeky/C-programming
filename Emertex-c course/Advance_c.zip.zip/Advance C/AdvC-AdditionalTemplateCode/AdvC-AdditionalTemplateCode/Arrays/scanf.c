#include <stdio.h>

int main()
{
    int x;

    printf("Enter int: ");
    scanf("%d", &x);

    printf("x = %d\n", x);
}
