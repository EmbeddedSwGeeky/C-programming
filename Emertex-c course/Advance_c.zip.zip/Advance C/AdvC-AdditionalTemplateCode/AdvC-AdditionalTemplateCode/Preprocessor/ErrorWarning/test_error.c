/* FILE: test_error.c
 * Description: 
 */

#include <stdio.h>

//#error "There is some error in code"
#warning "There is some warning in code"
int main()
{
    return 0;
}
