#include <stdio.h>

int count = 10;
int size;

int main()
{
    int x;

    printf("hello\n");
}
