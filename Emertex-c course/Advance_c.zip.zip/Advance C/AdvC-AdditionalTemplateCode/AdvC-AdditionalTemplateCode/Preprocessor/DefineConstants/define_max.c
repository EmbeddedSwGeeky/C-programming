#include <stdio.h>

#define MAX 100
#define PI 3.14

#define MEGA_BYTE (1024 * 1024)

#define PRINT_GREETING printf("Good morning")

int main()
{

    int size = MAX1;
    int arr[MEGA_BYTE];
    float r = 5;

    float area = PI * r * r;

    PRINT_GREETING;

    printf("%d %d\n", size, MAX);
    printf("MAX\n");

    printf("Area = %f\n", area);

    
    return 0;
}

