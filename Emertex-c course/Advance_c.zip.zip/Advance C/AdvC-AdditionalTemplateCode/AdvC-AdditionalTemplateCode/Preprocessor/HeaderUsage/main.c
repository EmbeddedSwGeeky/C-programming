/* FILE: main.c
 * Description: 
 */

#include <stdio.h>

#include "sum.h"

int main()
{
    int res = sum(5, 10);

    printf("sum = %d\n", res);

    return 0;
}
