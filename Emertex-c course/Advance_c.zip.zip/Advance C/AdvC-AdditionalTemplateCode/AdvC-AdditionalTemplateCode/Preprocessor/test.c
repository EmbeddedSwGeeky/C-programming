
#include "stdio.h"

int main()
{
    /* Print message. This comment will be removed by pre-processor */

    printf("hello\n");

}
