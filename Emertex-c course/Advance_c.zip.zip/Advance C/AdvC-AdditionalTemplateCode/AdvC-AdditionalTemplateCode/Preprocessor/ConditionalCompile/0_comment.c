#include <stdio.h>

int main()
{
#if 0
    puts("hello");
    printf("First case\n");
#else
    puts("world");
    printf("second case\n");
#endif

    return 0;

}
