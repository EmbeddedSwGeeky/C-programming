#include <stdio.h>

int main()
{
    int x, y, temp;

    /*
    x = x ^ y;
    /*
    y = x ^ y;
    */
    x = x ^ y;
    */

    return 0;
}
