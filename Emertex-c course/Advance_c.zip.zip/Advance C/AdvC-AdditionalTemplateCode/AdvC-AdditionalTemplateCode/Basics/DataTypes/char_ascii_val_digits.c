/* Program demonstrates that char literals are stored as
 * ascii values. Also demonstrates that value can be directly
 * assigned to chars
 */
#include <stdio.h>

int main()
{
    char c1 = '0';

    printf("%c %d\n", c1, c1);

    return 0;
}
