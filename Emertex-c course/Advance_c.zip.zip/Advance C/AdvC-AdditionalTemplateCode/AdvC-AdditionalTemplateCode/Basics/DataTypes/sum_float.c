/* Progrom to find sum of two numbers */
#include <stdio.h>

int main()
{
    float num1, num2;
    float result;

    num1 = 3.35;
    num2 = 5.66;

    result = num1 + num2;

    printf("%f\n", result); //Use %f to print float values

    return 0;
}
