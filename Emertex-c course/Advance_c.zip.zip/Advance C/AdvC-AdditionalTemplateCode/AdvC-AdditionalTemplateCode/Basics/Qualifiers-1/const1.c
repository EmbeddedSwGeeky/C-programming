#include <stdio.h>

int main()
{
    const int max;


    max = 500;


    printf("max = %d\n", max);

    return 0;
}
