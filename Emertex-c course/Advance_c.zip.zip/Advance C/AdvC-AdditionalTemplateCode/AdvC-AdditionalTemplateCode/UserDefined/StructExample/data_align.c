#include <stdio.h>

int main()
{
    int num1;
    char ch1;
    int num2;
    char ch2;

    printf("&num1 = %lu\n", &num1);
    printf("&ch1  = %lu\n", &ch1);
    printf("&num2 = %lu\n", &num2);

    return 0;
}
