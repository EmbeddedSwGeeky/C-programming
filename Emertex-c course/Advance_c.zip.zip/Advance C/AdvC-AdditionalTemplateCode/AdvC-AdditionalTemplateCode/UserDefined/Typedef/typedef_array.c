#include <stdio.h>

typedef int ARRAY[100];
int main()
{
    ARRAY arr;

    printf("%u\n", sizeof(arr));

    return 0;
}
