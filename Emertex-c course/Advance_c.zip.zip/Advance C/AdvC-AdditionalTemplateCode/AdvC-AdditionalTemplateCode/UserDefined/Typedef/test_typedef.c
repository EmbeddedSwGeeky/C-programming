#include <stdio.h>
#include "types.h"

int main()
{
    int32_t x = 50, y = 10;
    int64_t a = 50, b = 10;

    printf("sizeof x = %lu\n", sizeof(x));
    printf("sizeof a = %lu\n", sizeof(a));

}
