/* FILE: inner_scope.c
 * Description: 
 */

#include <stdio.h>

int x = 100;

int main()
{
    int x;

    printf("x = %d\n", x);

    return 0;
}
