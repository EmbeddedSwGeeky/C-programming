void func()
{
    char *ch;
    ch = (char*) malloc(10);

    // do something with ch
}

int main()
{
    func();

    //do something here
}
