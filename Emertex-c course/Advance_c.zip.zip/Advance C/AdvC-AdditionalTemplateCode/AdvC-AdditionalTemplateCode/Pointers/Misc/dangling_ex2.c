char* func()
{
   char str[10];
   strcpy(str,"Hello!");
   return(str); 
}


