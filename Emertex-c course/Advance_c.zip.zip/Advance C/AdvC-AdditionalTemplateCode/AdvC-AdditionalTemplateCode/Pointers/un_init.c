#include <stdio.h>

int main()
{
    int *ptr;

    printf("ptr = %p\n", ptr);
    printf("*ptr = %d\n", *ptr); 

    return 0;
}
