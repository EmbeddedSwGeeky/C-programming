#include <stdio.h>
int main() { int num1, num2, num3; int val = 0, i; val=~num1*(num2+num3) -(num1 +num2); val = ~num1 * (num2 + num3) - (num1 + num2); for (i = 0; i < 100; i++) { if (num2 > num3) { printf("%d is greater than %d\n", num2, num3); return 0; } } return 0; }
