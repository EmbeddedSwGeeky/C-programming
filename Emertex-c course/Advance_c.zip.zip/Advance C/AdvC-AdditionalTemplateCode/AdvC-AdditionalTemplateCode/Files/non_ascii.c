/* FILE: non_ascii.c
 * Description: 
 */

#include <stdio.h>
int main()
{
    char ch1 = 65;
    char ch2 = 129;

    putchar(ch1);
    putchar('\n');
    putchar(ch2);
    putchar('\n');

    return 0;
}
