/* FILE: print_dir_path.c
 * Description: 
 */

#include <stdio.h>
int main()
{
    puts("C:\temp\new");
    puts("C:\\temp\\new");
    return 0;
}
