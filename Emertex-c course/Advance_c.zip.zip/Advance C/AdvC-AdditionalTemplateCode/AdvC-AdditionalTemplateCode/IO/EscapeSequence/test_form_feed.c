#include <stdio.h>

int main()
{
    puts("hello");
    puts("\f");
    puts("world");
}
