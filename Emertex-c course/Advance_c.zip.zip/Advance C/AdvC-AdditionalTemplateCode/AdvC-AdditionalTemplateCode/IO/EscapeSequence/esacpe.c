#include <stdio.h>

int main()
{
    printf("Hello\rWorld\n");
    printf("Hello\b");
    printf("Hello\vWorld");
    return 0;
}
