#include <stdio.h>

int main()
{
    unsigned int x = 1 << 31;

    printf("uint x = %u\n", x);
    printf("uint x = %d\n", x);

    return 0;
}
