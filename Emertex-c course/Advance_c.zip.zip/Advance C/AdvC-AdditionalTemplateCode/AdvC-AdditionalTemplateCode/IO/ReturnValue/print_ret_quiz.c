/* FILE: print_ret_quiz.c
 * Description: 
 */

#include <stdio.h>
int main()
{
    printf("%d", printf("%d", printf("%d", 43)));
    return 0;
}
