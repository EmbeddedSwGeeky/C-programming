#include <stdio.h>

int main()
{
    int x, y;

    printf("Enter 2 numbers: ");
    scanf("%d%d", &x, &y);

    printf ("x = %d, y = %d\n", x, y);

    return 0;
}
