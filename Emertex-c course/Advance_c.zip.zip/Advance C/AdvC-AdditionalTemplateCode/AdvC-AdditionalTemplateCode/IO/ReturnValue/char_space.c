#include <stdio.h>

int main()
{
    char x, y;

    printf("Enter 2 chars: ");
    scanf("%c%c", &x, &y);

    printf ("x = %d, y = %d\n", x, y);

    return 0;
}
