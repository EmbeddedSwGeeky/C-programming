/* FILE: read_write.c
 * Description: 
 */

#include <stdio.h>
#include <string.h>
int main()
{
    printf("hello\n");
    //write(1, "hello\n", strlen("hello\n"));
    return 0;
}
