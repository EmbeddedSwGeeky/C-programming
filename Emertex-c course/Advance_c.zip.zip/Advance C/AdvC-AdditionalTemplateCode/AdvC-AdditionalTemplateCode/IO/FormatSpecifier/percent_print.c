/* FILE: percent_print.c
 * Description: 
 */

#include <stdio.h>
int main()
{
    printf("100%"); //Incorrect
    printf("100%%\n");
    return 0;
}
