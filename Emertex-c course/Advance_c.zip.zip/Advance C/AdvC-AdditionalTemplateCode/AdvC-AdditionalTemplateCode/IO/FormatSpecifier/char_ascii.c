/* FILE: char_ascii.c
 * Description: 
 */

#include <stdio.h>
int main()
{
    printf("%d\n", 65);
    printf("%c\n", 65);
    printf("%c\n", 'A');
    return 0;
}
