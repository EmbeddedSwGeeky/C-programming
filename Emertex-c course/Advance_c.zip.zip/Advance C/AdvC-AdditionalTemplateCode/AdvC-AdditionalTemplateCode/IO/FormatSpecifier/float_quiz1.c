#include <stdio.h>

int main()
{
    double val = 0.00000000789;

    printf("val = %.12f\n", val);

    return 0;
}
