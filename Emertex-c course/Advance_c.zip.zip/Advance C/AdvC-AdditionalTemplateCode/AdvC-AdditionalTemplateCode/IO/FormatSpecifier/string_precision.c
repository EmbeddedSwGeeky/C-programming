/* FILE: string_precision.c 
 * Description: 
 */

#include <stdio.h>

int main()
{
    char *str = "Hello World";
    printf("%.5s\n", str); //Print 5 chars
    return 0;
}
