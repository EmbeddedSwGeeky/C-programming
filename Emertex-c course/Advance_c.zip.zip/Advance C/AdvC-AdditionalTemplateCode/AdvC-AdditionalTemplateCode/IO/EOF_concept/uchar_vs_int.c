#include <stdio.h>

int main()
{
    unsigned char ch = -1;
    
    //if (255 == -1)
    if (ch == -1)
    {
    	puts("Yes");
    }
    else
    {
    	puts("Nope");
    }

    return 0;
}
