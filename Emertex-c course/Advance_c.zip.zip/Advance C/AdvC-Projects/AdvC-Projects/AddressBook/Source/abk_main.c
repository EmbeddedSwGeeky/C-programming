/*
	C Project
	Address Book

	26/Nov/2012

	Implementation C File

	MAIN CONSOLE PROGRAM

*/


int main(void)
{

}
