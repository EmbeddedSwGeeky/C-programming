/*
	C Project
	Address Book

	26/Nov/2012

	Implementation C File

	File Operatios.

*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "abk.h"


#define MAX_BUF 32

