#include <stdio.h>

void func(void)
{
	printf("Welcome!\n");

	return; // Use of return is optional
}

int main()
{
	func();

	return 0;
}
