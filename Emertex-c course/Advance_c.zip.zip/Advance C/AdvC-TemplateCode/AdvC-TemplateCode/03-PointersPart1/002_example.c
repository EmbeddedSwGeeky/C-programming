#include <stdio.h>

int main()
{
	int x;
	int *ptr;

	x = 5;
	ptr = &x;

	return 0;
}
