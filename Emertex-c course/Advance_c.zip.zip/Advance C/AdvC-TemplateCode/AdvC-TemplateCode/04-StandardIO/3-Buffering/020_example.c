#include <stdio.h>

int main()
{
	printf("Hello");

	return 0;
}
