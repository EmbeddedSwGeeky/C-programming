#include <stdio.h>

int main()
{
	char str[10];

	puts("Enter the string");
	gets(str);
	puts(str);

	return 0;
}
