#include <stdio.h>

int main()
{
	auto int i = 0;

	printf("i %d\n", i);

	return 0;
}
