#include <stdio.h>

int foo()
{
		int i = 0;

		printf("i %d\n", i);

		return i;
}

int main()
{
		foo();

		return 0;
}
