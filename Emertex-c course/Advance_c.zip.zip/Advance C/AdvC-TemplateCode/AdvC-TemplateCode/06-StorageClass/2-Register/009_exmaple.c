#include <stdio.h>

int main()
{
	register int i = 0;

	scanf("%d", &i);
	printf("i %d\n", i);

	return 0;
}
