#include <stdio.h>

static int x = 10;

int foo()
{
	printf("x %d\n", x);

	return 0;
}

int main()
{
	foo();

	return 0;
}
