int num;

#include <003_file2.h>

int main()
{
	puts(test());

	return 0;
}
