char *test(void)
{
	static char *str = "Hello";

	return str;
}
