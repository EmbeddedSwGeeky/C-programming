#include <stdio.h>
int sum(int, int);
int main()

{
		//PRINT Message
    printf("Hello\n");
    int x;
    x = sum(1,2);

	return 0;

}
int sum(int a, int y)
{
		return a + y;
}
