#include <stdio.h>

int main()
{
#line 25 "my_example.c"	
		printf("This is from file %s at line %d \n", __FILE__, __LINE__);

	return 0;
}
