#include <stdio.h>

typedef signed int		sint, si;
typedef unsigned int	uint, ui;
typedef signed char		s8;
typedef signed short	s16;
typedef signed int		s32;
typedef unsigned char	u8;
typedef unsigned short	u16;
typedef unsigned int	u32;

int main()
{
	u8 count = 200;
	s16 axis = -70; 

	printf("%u\n", count);
	printf("%d\n", axis);

	return 0;
}
