#include <stdio.h>

typedef unsigned int uint;

int main()
{
	uint number;

	return 0;
}
