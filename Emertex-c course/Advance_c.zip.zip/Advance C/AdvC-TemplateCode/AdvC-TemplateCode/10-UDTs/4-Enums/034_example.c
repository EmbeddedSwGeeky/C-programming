#include <stdio.h>

int main()
{
		typedef enum
		{
				red,
				blue
		} Color;


		int blue;

		printf("%d\n", blue);

		return 0;
}
