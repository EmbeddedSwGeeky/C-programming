#include <stdio.h>

enum bool
{
	e_false,
	e_true
};

int main()
{
	printf("%d\n", e_false);
	printf("%d\n", e_true);

	return 0;
}
