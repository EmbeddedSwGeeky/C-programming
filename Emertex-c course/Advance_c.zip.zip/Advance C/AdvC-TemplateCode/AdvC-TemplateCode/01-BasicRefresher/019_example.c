#include <stdio.h>

int main()
{
	int num1 = 5, num2 = 3;

	float num3 = (float) num1 / num2;

	printf("num3 is %f\n", num3);

	return 0;
}
