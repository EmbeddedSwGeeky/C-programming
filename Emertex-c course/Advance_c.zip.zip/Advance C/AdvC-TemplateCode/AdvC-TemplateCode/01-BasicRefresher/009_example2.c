#include <stdio.h>

int main()
{
	int num = 5;

	if (num < 5)
	{
		printf("num is smaller than 5\n");
	}
	else if (num > 5)
	{
		printf("num is greater than 5\n");
	}
	else
	{
		printf("num is equal to 5\n");
	}

	return 0;
}
