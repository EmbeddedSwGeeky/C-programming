#include <stdio.h>

int main()
{
	char option = 'A';
	int age = 12;
	float height = 5.5;

	printf("The character is %c\n", option);
	printf("The integer is %d\n", age);
	printf("The float is %f\n", height);

	return 0;
}

